t = tblish.dataset.USJudgeRatings;

figure
tblish.examples.plot_pairs (t(:,2:end));
title ("USJudgeRatings data")
