tblish.dataset.HairEyeColor

# TODO: Aggregate over sex and display a table of counts

# TODO: Port mosaic plot to Octave
