# TODO: Port this from R

# TODO: Port the anova output

# TODO: Port the fancy plot
# This involves a "mosaic plot", which is not supported by Octave, so this will
# take some work.
