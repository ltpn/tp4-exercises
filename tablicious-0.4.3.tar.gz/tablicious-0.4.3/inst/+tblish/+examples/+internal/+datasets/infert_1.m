t = tblish.dataset.infert;

# TODO: Port glm() (generalized linear model) stuff to Octave
