t = tblish.dataset.ChickWeight

tblish.examples.coplot (t, "Time", "weight", "Chick");
