t = tblish.dataset.lh;

plot (t.sample, t.lh);
xlabel ("Sample Number");
ylabel ("lh level");
