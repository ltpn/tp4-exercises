# TODO: Port this example from R
