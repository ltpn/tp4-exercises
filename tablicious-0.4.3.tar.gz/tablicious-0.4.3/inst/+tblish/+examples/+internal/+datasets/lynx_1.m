t = tblish.dataset.lynx;

plot (t.year, t.lynx);
xlabel ("Year");
ylabel ("Lynx Trapped");
