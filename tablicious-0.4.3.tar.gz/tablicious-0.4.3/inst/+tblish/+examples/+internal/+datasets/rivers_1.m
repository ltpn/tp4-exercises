tblish.dataset.rivers;

longest_river = max (rivers)
shortest_river = min (rivers)
