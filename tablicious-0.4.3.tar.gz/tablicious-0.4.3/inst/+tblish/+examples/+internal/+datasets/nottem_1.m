t = tblish.dataset.nottem;

# TODO: Port window() and arima() to Octave
