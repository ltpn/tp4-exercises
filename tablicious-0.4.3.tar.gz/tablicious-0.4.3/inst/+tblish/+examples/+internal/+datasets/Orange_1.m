t = tblish.dataset.Orange;

# TODO: Port coplot to Octave

# TODO: Linear model
