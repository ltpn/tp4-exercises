t = tblish.dataset.OrchardSprays;

tblish.examples.plot_pairs (t);
