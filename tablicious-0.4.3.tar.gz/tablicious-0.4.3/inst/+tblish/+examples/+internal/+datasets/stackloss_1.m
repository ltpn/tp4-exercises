t = tblish.dataset.stackloss;

# TODO: Create linear model and print summary
