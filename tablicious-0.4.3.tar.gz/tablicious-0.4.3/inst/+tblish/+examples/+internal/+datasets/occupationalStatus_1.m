x = tblish.dataset.occupationalStatus;

# TODO: Port to Octave
