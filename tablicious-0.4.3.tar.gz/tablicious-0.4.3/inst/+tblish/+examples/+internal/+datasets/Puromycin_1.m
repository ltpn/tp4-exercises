t = tblish.dataset.Puromycin;

# TODO: Port example to Octave
