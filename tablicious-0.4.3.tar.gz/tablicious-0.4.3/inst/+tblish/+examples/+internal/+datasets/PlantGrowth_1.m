t = tblish.dataset.PlantGrowth;

# TODO: Port anova to Octave
