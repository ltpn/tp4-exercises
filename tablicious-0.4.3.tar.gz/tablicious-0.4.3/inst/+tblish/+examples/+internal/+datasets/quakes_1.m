t = tblish.dataset.quakes;

tblish.examples.plot_pairs (t);
