t = tblish.dataset.USArrests;

summary (t);

tblish.examples.plot_pairs (t(:,2:end));

# TODO: Difference between USArrests and its correction

# TODO: +/- 0.5 to restore the original <n>.5 percentages
