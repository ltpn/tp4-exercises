tblish.dataset.UKDriverDeaths;
d = UKDriverDeaths;
s = Seatbelts;

# TODO: Port the model and plots to Octave
