t = tblish.dataset.ToothGrowth;

tblish.examples.coplot (t, "dose", "len", "supp");

# TODO: Port Lowess smoothing to Octave
