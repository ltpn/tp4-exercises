t = tblish.dataset.freeny;

summary (t)

tblish.examples.plot_pairs (removevars (t, "date"))

# TODO: Create linear model and print summary

# TODO: Linear model plot
