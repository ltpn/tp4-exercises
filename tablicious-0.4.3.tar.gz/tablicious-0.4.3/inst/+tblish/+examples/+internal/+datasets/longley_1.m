t = tblish.dataset.longley;

# TODO: Linear model
# TODO: opar plot
