tblish.dataset.volcano;

# TODO: Figure out how to do a topo map in Octave. Just a gridded color plot
# should be fine. And then maybe do a 3-d mesh plot.
