t = tblish.dataset.Nile;

figure
plot (t.year, t.flow);

# TODO: Port the rest of the example to Octave
