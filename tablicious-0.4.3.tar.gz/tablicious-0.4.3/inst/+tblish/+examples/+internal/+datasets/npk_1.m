t = tblish.dataset.npk;

# TODO: Port aov() and LM to Octave
