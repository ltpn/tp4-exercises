t = tblish.dataset.precip;

# TODO: Port dot plot to Octave
