tblish.dataset.UCBAdmissions;

# TODO: Port mosaic plot to Octave
