t = tblish.dataset.islands;

# TODO: Port dot chart to Octave
