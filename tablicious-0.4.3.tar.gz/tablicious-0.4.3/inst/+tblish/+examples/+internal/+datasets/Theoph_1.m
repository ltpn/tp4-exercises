t = tblish.dataset.Theoph;

# TODO: Coplot
# TODO: Yet another linear model to port to Octave
